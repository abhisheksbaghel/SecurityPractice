package com.Gateway.SecuredGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuredGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
