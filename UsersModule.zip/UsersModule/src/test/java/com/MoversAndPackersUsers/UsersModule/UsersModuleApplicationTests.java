package com.MoversAndPackersUsers.UsersModule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
